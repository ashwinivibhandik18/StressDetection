from django.shortcuts import render
from .models import Stress
import joblib


# Create your views here.
def home(request):
    return render(request, "index.html")


def index(request):
    # with open('stress.pkl', 'rb') as file:
    #     loaded_model = pickle.load(file)
    cls=joblib.load('model.sav')

    if request.method == 'POST':
       my_list = []
       ip1 = request.POST['input1']
       my_list.append(float(ip1))
       ip2 = request.POST['input2']
       my_list.append(float(ip2))
       ip3 = float(request.POST['input3'])
       my_list.append(ip3)
       print(my_list)

    ans = cls.predict([my_list])
    val = ans.item()
    op = ""
    if val == 0:
        op = 'Low Stress'
    elif val == 1:
        op = 'Normal Stress'
    elif val == 2:
        op = 'High Stress'

        # ans=loaded_model.predict([my_list])
    return render(request, "index.html",{'ans':op})
    

# def save_stress(request):
#     s_temp = request.POST["input1"]
#     s_humidity = request.POST["input2"]
#     s_step = request.POST["input3"]
#     s_obj = Stress(temperature=s_temp, humidity=s_humidity, step_count=s_step)
#     s_obj.save()
#     return render(request, "index.html", {'msg': "Data saved successfully!"})

