from django.db import models

class Stress(models.Model):
    temerature = models.FloatField()
    humidity = models.FloatField()
    step_count = models.IntegerField()

    def __str__(self):
        return self.temerature