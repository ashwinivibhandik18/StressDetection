from django.contrib import admin
from .models import Stress
# Register your models here.
admin.site.register(Stress)